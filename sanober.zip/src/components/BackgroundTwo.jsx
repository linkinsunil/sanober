const BackgroundTwo = () => {
  return <div>BackgroundTwo</div>;
};

export default BackgroundTwo;
